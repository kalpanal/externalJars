package com.ibm.jira.core.domain.meta.fields;

/**
 * Created by cschulc on 16.03.16.
 */
public class FixVersionFieldMetaBean extends FieldMetaBean {


}

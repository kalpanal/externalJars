package com.ibm.jira.core.domain.system;

/**
 * Created by cschulc on 11.09.2016.
 */
public enum AssigneeTypeEnum {
    UNASSIGNED, PROJECT_LEAD
}

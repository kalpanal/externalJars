package com.ibm.jira.main;

import java.sql.Connection;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.ibm.jira.JiraRestClient;
import com.ibm.jira.core.domain.FieldsBean;
import com.ibm.jira.core.domain.IssueBean;
import com.ibm.jira.core.domain.JqlSearchResult;
import com.ibm.jira.core.domain.ProjectBean;
import com.ibm.jira.core.domain.customFields.CustomFieldBaseBean;
import com.ibm.jira.core.domain.field.FieldBean;
import com.ibm.jira.core.jql.EField;
import com.ibm.jira.core.jql.EOperator;
import com.ibm.jira.core.jql.JqlBuilder;
import com.ibm.jira.core.jql.JqlConstants;
import com.ibm.jira.core.jql.JqlSearchBean;
import com.ibm.jira.core.jql.SortOrder;

public class DefectsManager {

	
	public void bulkInsertDefectsForAllProjects(Connection connect, List<ProjectBean> projectBeans, JiraRestClient jiraRestClient) throws InterruptedException, ExecutionException{
		//for(ProjectBean projectBean:projectBeans) {
			JqlSearchBean jsb = new JqlSearchBean();
			JqlBuilder builder = new JqlBuilder();
			String jql = builder.addCondition(EField.PROJECT, EOperator.EQUALS, "J2REPO")
					.and().addCondition(EField.STATUS, EOperator.NOT_EQUALS, "Cancelled")
					//.and().addCondition(EField.CREATED, EOperator.GREATER_THAN, "2018-04-05")
					.and().addCondition(EField.ISSUE_TYPE, EOperator.EQUALS, "Bug")
					.orderBy(SortOrder.ASC, EField.CREATED);
			jsb.setJql(jql);
			//jsb.addField(EField.ISSUE_KEY, EField.STATUS, EField.DUE, EField.SUMMARY, EField.ISSUE_TYPE, EField.PRIORITY, EField.UPDATED, EField.TRANSITIONS);
			//jsb.addExpand(EField.TRANSITIONS);
			Future<JqlSearchResult> future = jiraRestClient.getSearchClient().searchIssues(jsb);
			JqlSearchResult jqlSearchResult = future.get();
			
			List<IssueBean> issueBeans = jqlSearchResult.getIssues();
			
			System.out.println("Total defects count --------->"+issueBeans.size());
			
			for(IssueBean issueBean:issueBeans) {
				System.out.println(("Defects created on ===>"+issueBean.getFields().getCreated()));
				System.out.println(("Defects created on ===>"+issueBean.getFields().getCreated()));
				FieldsBean fieldsBean = issueBean.getFields();
				System.out.println("fieldsBeanfieldsBeanfieldsBean Kalpana+"+fieldsBean.toString());
				List<CustomFieldBaseBean> customFieldBeanList = fieldsBean.getCustomFields();
				/*for(CustomFieldBaseBean customBean:customFieldBeanList) {
					System.out.println("Kalpana it is a custome field------->"+customBean.getId());
					
				}*/
					
			//}
			
		}

	}
}

package com.ibm.jira.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Properties;

public class MySqlDBAccess {
	
	public  static Connection getConnection() throws Exception {
		Connection connect = null;
		try {
			/*
			 * // This will load the MySQL driver, each DB has its own driver
			 * Class.forName("com.mysql.jdbc.Driver"); // Setup the connection with the DB
			 * connect = DriverManager .getConnection("jdbc:mysql://localhost/cioclone?" +
			 * "user=root&password=password");
			 */
			String resourceName = "db.properties"; // could also be a constant
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			Properties props = new Properties();
			try (InputStream resourceStream = loader.getResourceAsStream(resourceName)) {
				props.load(resourceStream);
			}

			String driver = props.getProperty("jdbc.driver");
			if (driver != null) {
				Class.forName(driver);
			}

			String url = props.getProperty("jdbc.url");
			String username = props.getProperty("jdbc.username");
			String password = props.getProperty("jdbc.password");
			System.out.println("connection db properties ======>" + url);
			connect = DriverManager.getConnection(url, username, password);
			System.out.println("connection status ======>" + connect.toString());

		} catch (Exception e) {
			throw e;
		} finally {
			//close();
			try {
				/*if (connect != null) {
					connect.close();
				}*/
				
			}catch(Exception ex) {
				
			}
		}
		return connect;
	}

	private static void writeMetaData(ResultSet resultSet) throws SQLException {
		// Now get some metadata from the database
		// Result set get the result of the SQL query

		System.out.println("The columns in the table are: ");

		System.out.println("Table: " + resultSet.getMetaData().getTableName(1));
		for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
			System.out.println("Column " + i + " " + resultSet.getMetaData().getColumnName(i));
		}
	}

	private static void writeResultSet(ResultSet resultSet) throws SQLException {
		// ResultSet is initially before the first data set
		while (resultSet.next()) {
			// It is possible to get the columns via name
			// also possible to get the columns via the column number
			// which starts at 1
			// e.g. resultSet.getSTring(2);
			String user = resultSet.getString("myuser");
			String website = resultSet.getString("webpage");
			String summary = resultSet.getString("summary");
			Date date = resultSet.getDate("datum");
			String comment = resultSet.getString("comments");
			System.out.println("User: " + user);
			System.out.println("Website: " + website);
			System.out.println("summary: " + summary);
			System.out.println("Date: " + date);
			System.out.println("Comment: " + comment);
		}
	}

	
}
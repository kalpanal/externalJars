package com.ibm.jira.main;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.configuration.ConfigurationException;

import com.ibm.jira.core.domain.IssueBean;
import com.ibm.jira.core.domain.JqlSearchResult;
import com.ibm.jira.core.domain.ProjectBean;
import com.ibm.jira.core.jql.EField;
import com.ibm.jira.core.jql.EOperator;
import com.ibm.jira.core.jql.JqlBuilder;
import com.ibm.jira.core.jql.JqlConstants;
import com.ibm.jira.core.jql.JqlSearchBean;
import com.ibm.jira.core.jql.SortOrder;
import com.ibm.jira.core.misc.RestPathConstants;
import com.ibm.jira.util.MySqlDBAccess;
import com.ibm.jira.JiraRestClient;


public class JiraExtractMainClass {

	static Connection connection = null;
	public static void main(String[] args) throws Exception {
		try {

			final String CONFIGFILENAME = "C:\\eclipseWorkspace\\jira-rest-client.properties";

			final String URL_PARAM = "jira.server.url";
			final String LOGIN_PARAM = "jira.user.id";
			final String PASSWORD_PARAM = "jira.user.pwd";

			final String USERNAME_TO_SEARCH = "admin";
			String ISSUEKEY_TO_SEARCH = "DEMO-1";
			final String PROJECT_TO_SEARCH = "DEMO";

			//String testSystemUrl = "http://localhost:2990/jira";
			String login = "admin";
			String password = "password";
			String path = Thread.currentThread().getContextClassLoader().getResource("").getPath();
			Properties config = new Properties();
			config.load(new FileInputStream(CONFIGFILENAME));
			String testSystemUrl = config.getProperty(URL_PARAM);
			login = config.getProperty(LOGIN_PARAM);
			password = config.getProperty(PASSWORD_PARAM);

			JiraRestClient jiraRestClient;		
			ExecutorService executorService = Executors.newFixedThreadPool(100);
			//  ProxyHost proxy = new ProxyHost("proxy", 3128);
			URI uri = new URI(testSystemUrl);
			jiraRestClient = new JiraRestClient(executorService);
			jiraRestClient.connect(uri, login, password);
			connection = MySqlDBAccess.getConnection();

			Future<List<ProjectBean>> futureProject = jiraRestClient.getProjectClient().getAllProjects();
			List<ProjectBean> projectBeans = futureProject.get();


			ProjectsManager projectsManager = new ProjectsManager();
			projectsManager.insertActiveProjects(connection, projectBeans);         
			DefectsManager defectsManager = new DefectsManager();
			defectsManager.bulkInsertDefectsForAllProjects(connection, projectBeans, jiraRestClient);

				
	}catch(Exception ex) {

	}
	finally {
		//close();
		try {
			if (connection != null) {
				connection.close();
			}

		}catch(Exception ex) {

		}
	}

	}
}

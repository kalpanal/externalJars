package com.ibm.jira.main;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import com.ibm.jira.core.domain.ProjectBean;

public class ProjectsManager {


	public static void insertActiveProjects(Connection connect, List<ProjectBean> projectBeans) throws IOException, SQLException {
		PreparedStatement preparedStatement = null;

		
		
		try {
			String resourceName = "db.properties"; // could also be a constant
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			Properties props = new Properties();
			try(InputStream resourceStream = loader.getResourceAsStream(resourceName)) {
				props.load(resourceStream);
			}
			preparedStatement = connect.prepareStatement(props.getProperty("INSERT_PROJECT_SQL")+"");
			for(ProjectBean projectBean:projectBeans) {
	        	 System.out.println("project Key===>"+projectBean.getKey());
	        	 System.out.println("project Name===>"+projectBean.getName());
	        		preparedStatement.setString(1, projectBean.getKey());
	    			preparedStatement.setString(2, projectBean.getName());
	    			preparedStatement.setTimestamp(3, new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
	    			//preparedStatement.setTimestamp(3, projectBean.);
	    			preparedStatement.addBatch();
	         }

			preparedStatement.executeBatch();

			/* preparedStatement = connect
                .prepareStatement("SELECT myuser, webpage, datum, summary, COMMENTS from feedback.comments");
        resultSet = preparedStatement.executeQuery();
        writeResultSet(resultSet);

        // Remove again the insert comment
        preparedStatement = connect
        .prepareStatement("delete from feedback.comments where myuser= ? ; ");
        preparedStatement.setString(1, "Test");
        preparedStatement.executeUpdate();

        resultSet = statement
        .executeQuery("select * from feedback.comments");
        writeMetaData(resultSet);*/



		}catch(Exception e) {
			throw e;
		}finally{
			try {


				if (preparedStatement != null) {
					preparedStatement.close();
				}

			}catch(Exception e) {

			}
		}
	}
}
package com.ibm.jira.core.domain.customFields;

import com.ibm.jira.core.domain.ProjectBean;

/**
 * Created by cschulc on 22.02.16.
 */
public class ProjectSelectBean extends CustomFieldBaseBean {

    private ProjectBean project;

    public ProjectBean getProject() {
        return project;
    }

    public void setProject(ProjectBean project) {
        this.project = project;
    }
}

package com.ibm.jira.core.domain.customFields;

import com.ibm.jira.core.domain.BaseBean;

/**
 * Created by cschulc on 22.02.16.
 */
public class CustomFieldBaseBean extends BaseBean {

    private CustomFieldType type;

    public CustomFieldType getType() {
        return type;
    }

    public void setType(CustomFieldType type) {
        this.type = type;
    }
}

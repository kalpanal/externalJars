package com.ibm.jira.client;

import com.ibm.jira.core.domain.JqlSearchResult;
import com.ibm.jira.core.domain.filter.FilterBean;
import com.ibm.jira.core.jql.JqlSearchBean;
import com.ibm.jira.core.util.RestException;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Future;


/**
 * User: Christian Schulze Email: c.schulze@micromata.de Date: 31.07.2014
 */
public interface SearchClient {


    /**
     * Performs an extended search for issues given by the project.
     *
     * @return list of issues
     * @throws com.ibm.jira.coreutil.RestException
     */
    Future<JqlSearchResult> searchIssues(JqlSearchBean jsb);

    /**
     * Create a new Search Filter for the logged in User
     *
     * @param filter
     * @return
     */
    Future<FilterBean> createSearchFilter(FilterBean filter);


    /**
     * Get favorite Filter for JqlSearch for the logged in User
     *
     * @return List of FilterBeans
     */
    Future<List<FilterBean>> getFavoriteFilter();

    /**
     * Get Filter by Id
     *
     * @param id the id of the filter
     * @return FilterBean
     */
    Future<FilterBean> getFilterById(String id);



}
